"""Discord bot package marker."""
