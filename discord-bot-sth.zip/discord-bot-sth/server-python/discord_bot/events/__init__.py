"""Discord bot events package."""
